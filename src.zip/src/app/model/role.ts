export class Role{

  User ="User";
  Admin ="Admin"
}
