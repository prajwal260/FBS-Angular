import { BookDetails } from './book-details';

describe('BookDetails', () => {
  it('should create an instance', () => {
    expect(new BookDetails()).toBeTruthy();
  });
});
