export class BookDetails {
    
        date:''
        destination:''
        flightid: ''
        mailId: ''
        mobile: ""
        passengerList:any
        sourceFlight: ""
        pnr:""
      
    }

