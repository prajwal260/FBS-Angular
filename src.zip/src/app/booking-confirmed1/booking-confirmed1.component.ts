import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-booking-confirmed1',
  templateUrl: './booking-confirmed1.component.html',
  styleUrls: ['./booking-confirmed1.component.css']
})
export class BookingConfirmed1Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
