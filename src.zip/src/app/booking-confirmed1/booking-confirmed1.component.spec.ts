import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BookingConfirmed1Component } from './booking-confirmed1.component';

describe('BookingConfirmed1Component', () => {
  let component: BookingConfirmed1Component;
  let fixture: ComponentFixture<BookingConfirmed1Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BookingConfirmed1Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BookingConfirmed1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
