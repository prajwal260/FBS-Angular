import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddScheduleFlight1Component } from './add-schedule-flight1.component';

describe('AddScheduleFlight1Component', () => {
  let component: AddScheduleFlight1Component;
  let fixture: ComponentFixture<AddScheduleFlight1Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddScheduleFlight1Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddScheduleFlight1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
