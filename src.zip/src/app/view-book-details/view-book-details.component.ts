import { Component, OnInit } from '@angular/core';
import { BookDetailsService } from '../services/book-details.service';
import { Router } from '@angular/router';
import { BookDetails } from '../model/book-details';

@Component({
  selector: 'app-view-book-details',
  templateUrl: './view-book-details.component.html',
  styleUrls: ['./view-book-details.component.css']
})
export class ViewBookDetailsComponent implements OnInit {
  pnrNoData:BookDetails;
  pnr:number;
  show:boolean=false;
  passengerId:'';
  name:'';
  age:'';
  gender:'';
  sourceFlight: ""
  destination:''
  mailId:''
  date:""

  constructor(private bookServiceDetails : BookDetailsService, private route :Router) { }

  ngOnInit(): void {
    this.pnrNoData=new BookDetails()
  }

  searchBookingDetails(pnr:number):any{
 
    this.bookServiceDetails.searchBookingDetails(pnr).subscribe((pnrNoData:BookDetails)=>
    this.pnrNoData=pnrNoData);
    this.show=true;
    this.pnrNoData.date=this.date
    this.pnrNoData.destination=this.destination
    this.pnrNoData.mailId=this.mailId
    console.log(pnr);
    this.pnrNoData.passengerList=[{"passengerId":this.passengerId,"name":this.name,
    "age":this.age, "gender":this.gender}];
    console.log("Get data "+this.pnrNoData);
}

  idValid:boolean=false;
validateId(){
    if(this.pnr>9999999999999){
        this.idValid=true;
    }
    else if(this.pnr<1){
        this.idValid=true;
    }else{
        this.idValid=false;
    }
}
  add(){
    this.route.navigate(['addBookData']);
}
view(){
    this.route.navigate(['/ticket/pnr']);
}
}
