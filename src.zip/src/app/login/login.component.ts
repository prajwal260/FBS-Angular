import { Component, OnInit } from '@angular/core';
import { User } from '../model/user.component';
import { Router } from '@angular/router';
import { AuthenticationService } from '../services/authentication.service';
import { ThrowStmt } from '@angular/compiler';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  userId:number=null
  userName:string;
  userPhone:number;
  userPassword:string;
  userEmail:string;
  active:boolean;
  roles:string;
  user : User = new User();
  roleData : string[];

  // username = 'admin';
  // password = 'admin123';
  
  constructor(private router: Router,
    private loginservice: AuthenticationService) {
      this.roleData = [
        'admin',
        'user'
      ]
     }

  ngOnInit(): void {
    this.userEmail = '';
    this.userPassword = '';
  }

  // Check user for authenticatoin
//   checkLogin() {
//     this.router.navigate(["welcomeAdmin"]).then(()=> {
//       window.location.reload();
//     });
// }
checkLogin() {
  this.user.userEmail = this.userEmail;
  this.user.userPassword = this.userPassword;
  this.user.roles = this.roles;
  this.loginservice.checkLogin(this.user).subscribe(res => {

    if(res == null) {
      alert("Uername or password is wrong");
      this.ngOnInit();
    }else {
      console.log("Login successful");
      this.router.navigate(["welcomeAdmin"]).then(()=> {
        window.location.reload();
      });
      localStorage.setItem("token",res.token);

      if(this.roles == 'user') {
        this.router.navigate(['/user']);
      } 

      if( this.roles == 'admin') {
        this.router.navigate(['/admin']);
      }
    }
  }, err => {
    alert("Login failed");
    this.ngOnInit();
  })
}
}
