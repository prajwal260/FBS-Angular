import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BookDetails } from '../model/book-details';
import { Observable } from 'rxjs';
// import { profileEnd } from 'console';

@Injectable({
  providedIn: 'root'
})
export class BookDetailsService {

  bookingUrl:string='';

  constructor(private http : HttpClient) { 
    this.bookingUrl = "http://localhost:9092/flight/booking";
  }

  addBooking(bookingData : BookDetails): Observable<any> {
    return this.http.post<any>(this.bookingUrl,bookingData);
}

searchBookingDetails(pnr: number) {
  return this.http.get('http://localhost:9092/flight/ticket/'+pnr);
}

}