import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { User } from '../model/user.component';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {

  loginUrl : string = '';
  signUpUrl : string = '';
  constructor(private httpClient: HttpClient) {
    this.loginUrl = 'http://localhost:8001/login/user/login';
    this.signUpUrl = 'http://localhost:8001/login/user/register';
   }

   checkLogin(user : User) : Observable<any> {
    return this.httpClient.post<any>(this.loginUrl,user);
  }
  // Adds a new User
  signUp(user : User) : Observable<any> {
    return this.httpClient.post<any>(this.signUpUrl,user);
  }

  //Retrieves user token and checks authentication
  authenticate(username, password) {

    return this.httpClient.post<any>('`${environment.apiUrl/authenticate',
    {username, password}).subscribe(
      userData => {
        sessionStorage.setItem('username', username);
        let tokenStr = 'Bearer' +userData.token;
        sessionStorage.setItem('token', tokenStr);
        return userData;
      }
    );
  }

  // Checks whether the user is logged in
  isUserLoggedIn():boolean {
    let user = sessionStorage.getItem('username')
    return !(user === null)
  }

  // Removes user session(logout)
  logOut() {
    sessionStorage.removeItem('username');
  }

  // Retrives role of user(customer/admin)
  getRole(username:String) {
    return this.httpClient.get('http://localhost:9092/getRole?username='+ username);
  }

  // // Adds a new User
  // signUp(user: User) {
  //   return this.httpClient.post('http://localhost:9092/signup', user);
  // }
  makeApiCall() {
    
  }

}
