import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FmsHomeComponent } from './fms-home.component';

describe('FmsHomeComponent', () => {
  let component: FmsHomeComponent;
  let fixture: ComponentFixture<FmsHomeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FmsHomeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FmsHomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
