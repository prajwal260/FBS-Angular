import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fms-home',
  templateUrl: './fms-home.component.html',
  styleUrls: ['./fms-home.component.css']
})
export class FmsHomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
