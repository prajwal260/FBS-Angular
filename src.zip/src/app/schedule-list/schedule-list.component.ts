import { Component, OnInit } from '@angular/core';
import { Observable, scheduled } from 'rxjs';
import { Flight } from '../model/flight.component';
import { FlightService } from '../services/flight.service';
import { ScheduledFlight } from '../model/scheduled-flight';
import { ScheduledFlightService } from '../services/scheduled-flight.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-flight-list',
  templateUrl: './schedule-list.component.html',
  styleUrls: ['./schedule-list.component.css']
})
export class ScheduledFlightListComponent implements OnInit {
  Scheduledflights:Observable<ScheduledFlight[]>;
  constructor(private ScheduledflightService: ScheduledFlightService, private router: Router) { }

  ngOnInit(){
    this.reloadData();
  }
reloadData()
 {
 this.Scheduledflights=this.ScheduledflightService.showScheduleFlights();
  }
//  removeFlight(flightNo: number){
//    this.ScheduledflightService.removeScheduleFlight(flightNo)
//     .subscribe(
//       data=>{
//         console.log(data);
//         this.reloadData();
//       },
//       error=> console.log(error));
//   }
  ScheduledflightDetails(flightNo:number)
  {
    this.router.navigate(['flightDetails',flightNo]);
  }
  modifyFlight(flightNo: number)
  {
    this.router.navigate(['updateFlight',flightNo]);
  }
}
