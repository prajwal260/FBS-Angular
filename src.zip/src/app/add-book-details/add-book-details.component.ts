import { Component, OnInit } from '@angular/core';
import { BookDetailsService } from '../services/book-details.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-book-details',
  templateUrl: './add-book-details.component.html',
  styleUrls: ['./add-book-details.component.css']
})
export class AddBookDetailsComponent implements OnInit {

  constructor(private bookServiceDetails : BookDetailsService, private route :Router) { }

  ngOnInit(): void {
  }
  add(){
    this.route.navigate(['addBookData']);
  }

  view(){
    this.route.navigate(['ticket/pnr']);
  }

}
