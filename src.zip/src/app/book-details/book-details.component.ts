import { Component, OnInit } from '@angular/core';
import { BookDetails } from '../model/book-details';
import { BookDetailsService } from '../services/book-details.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-book-details',
  templateUrl: './book-details.component.html',
  styleUrls: ['./book-details.component.css']
})
export class BookDetailsComponent implements OnInit {

  date:''
  destination:''
  flightid: ''
  mailId: ''
  mobile: ""
  passengerId:'';
  name:'';
  age:'';
  gender:'';
  sourceFlight: ""
  pnr:""
  

  book = new BookDetails();
  constructor(private bookServiceDetails : BookDetailsService, private route :Router) { }

  addBooking(){
    
    this.book.date=this.date
    this.book.destination=this.destination
    this.book.sourceFlight=this.sourceFlight
    this.book.flightid=this.flightid
    this.book.mailId=this.mailId
    this.book.mobile=this.mobile
    this.book.passengerList=[{"passengerId":this.passengerId,"name":this.name,
    "age":this.age, "gender":this.gender}];
    console.log(this.book);
    
    const observable = this.bookServiceDetails.addBooking(this.book);
    observable.subscribe((res: any)  => { // success handler
      console.log(res);
      if(res == null) {
        alert("Booking Failed");
      }else {
        console.log("Booking Successful");
        console.log(res);
        alert("Booking Successful: Your booking id:" + res.pnrNo);
      }
    }, err => {
      alert("Booking failed.");
    })
  }
  ngOnInit(): void {
  }
  add(){
    this.route.navigate(['addBookData']);
}
view(){
    this.route.navigate(['ticket/pnr']);
}
}
